package com.first.testcase;

import com.first.uiframework.DriverFactory;
import com.first.pages.LoginPage;
import com.first.pages.MainPage;
import com.first.utils.AssertUtils;
import org.dom4j.DocumentException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by Administrator on 2017-08-16.
 */
public class LoginTest {
    WebDriver driver;
    AssertUtils assertUtils;
    @BeforeMethod
    public void setup(){
//        System.setProperty("webdriver.chrome.driver","webdriver/chromedriver.exe");
//        driver=new ChromeDriver();
        try {
            assertUtils = new AssertUtils();
            driver = DriverFactory.getChromeDriver();
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }catch (Exception e){
            Assert.fail("Error:启动浏览器失败，测试停止");
        }
    }
    @Test
    public void loginTest1() throws InterruptedException, DocumentException {
        LoginPage lp=new LoginPage(driver);
        lp.loginOperate("test001","abc123456");
        Thread.sleep(3000);
        //写断言
        MainPage mp=new MainPage(lp.getDriver());
        String name=mp.getLoginName();
        Assert.assertEquals(name.contains("zhangsan"),true,"登录测试成功");
    }
    @Test
    public void loginTest2() throws InterruptedException, DocumentException {
        LoginPage lp=new LoginPage(driver);
        String value =lp.loginFailOperate("admin","123");
        Thread.sleep(3000);
        assertUtils.checkContainsString(value,"登录失败","登录测试失败");
        //Assert.assertEquals(value.contains("登录失败"),true,"登录测试失败");
    }
    @AfterMethod
    public void quit() throws InterruptedException {
        Thread.sleep(3000);
        driver.close();

    }
}
