package com.first.pages;

import com.first.configs.LocalConfig;
import com.first.uiframework.BasePage;
import com.first.uiframework.Locator;
import org.dom4j.DocumentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created by Administrator on 2017-08-16.
 */
public class LoginPage extends BasePage {
    //WebDriver driver;
//    private WebElement usernameInputBox;
//    private WebElement passwdInputBox;
//    private WebElement loginButton;


    public WebDriver getDriver(){
        return driver;
    }
    //构造函数
    public LoginPage(WebDriver driver) throws DocumentException {
        super(driver);
        //driver.get(LocalConfig.URL);
        openUrl(LocalConfig.URL);
    }
    Locator usernameInputBox=getLocator("usernameInputBox");
    Locator passwordInputBox=getLocator("passwordInputBox");
    Locator loginButton=getLocator("loginButton");
    //登录成功动作
    public MainPage loginOperate(String username, String password) throws DocumentException {
        input(usernameInputBox,username);
        input(passwordInputBox,password);
        click(loginButton);
        return new MainPage(getDriver());
    }
    //登录失败
    public String loginFailOperate(String username,String passwd) throws InterruptedException {
        input(usernameInputBox,username);
        input(passwordInputBox,passwd);
        click(loginButton);
        Thread.sleep(3000);

//      Alert alert=driver.switchTo().alert();
//       String value=alert.getText();
        String value=alertGetText();
        alertAccept();//在提示框点确认
        return value;
    }
}
